# Zynark — Books by M. F. Daif

This is the official landing page for **Zynark**, publishing works by **M. F. Daif**.

## Deploy on Netlify (GitHub method)

1. Create a new GitHub repository (e.g., `zynark-landing`).
2. Add/commit these files, then push to GitHub.
3. In Netlify: **Add new site → Import from Git → GitHub → select repo**.
4. Build settings:
   - **Framework**: None (static site)
   - **Build command**: _leave empty_
   - **Publish directory**: `.`
5. Click **Deploy**.

## Local development

Just open `index.html` in a browser, or run a local server:

```bash
python -m http.server 5173
```
then visit `http://localhost:5173`.

## Custom domain

After the first deploy, in Netlify go to **Site settings → Domain management** to add `zynark.store` (or another domain).

## Editing content

- Replace placeholder book covers by adding images into `/assets` and updating the `.thumb` elements or swapping in `<img>` tags.
- Update prices, titles, and links directly inside `index.html`.
- If you need multiple pages, keep using static HTML files or move to a small JS router (Netlify fallback is already configured).
